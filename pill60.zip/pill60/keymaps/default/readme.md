![Pill60 Layout Image](https://i.imgur.com/LIW18XJ.png)

# Default Pill 60 Layout

This is the default layout that comes flashed on every 60% board. For the most
part it's a straightforward and easy to follow layout. Except the backspace is split, and right shift is split.