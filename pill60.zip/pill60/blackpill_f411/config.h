/* Copyright 2019
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

/* #define MATRIX_COL_PINS \
	{ B14, A6, A5, A4, A3, A2, A1, C15, B12, B15, A7, B1 }
#define MATRIX_ROW_PINS \
    { B0, B3, B4, B6, B13, A15 }
#define UNUSED_PINS \
    { A8, A9, A11, A12 } */
	

#define MATRIX_COL_PINS \
	{ B14, C13, C14, A4, A3, A2, A1, C15, B12, B15, B9, B1 }
#define MATRIX_ROW_PINS \
    { B0, B3, B4, B6, B13, A15 }
#define UNUSED_PINS \
    { A11, A12 }

#define SPI_DRIVER                           SPID1
#define SPI_SCK_PIN                          A5
#define SPI_SCK_PAL_MODE                     5
#define SPI_MOSI_PIN                         A7
#define SPI_MOSI_PAL_MODE                    5
#define SPI_MISO_PIN                         A6
#define SPI_MISO_PAL_MODE                    5

/* Trackball */
#define PMW3360_CS_PIN                       B7
#define PMW3360_SPI_MODE                     3
#define PMW3360_SPI_DIVISOR                  64
#define PMW3360_FIRMWARE_UPLOAD_FAST
//#define POINTING_DEVICE_INVERT_X
#define POINTING_DEVICE_INVERT_Y
//#define ROTATIONAL_TRANSFORM_ANGLE  -25

/* Encoder */
#define ENCODERS_PAD_A {B10, B10}
#define ENCODERS_PAD_B {A14, A13}    //C13

#define ENCODER_RESOLUTION 4